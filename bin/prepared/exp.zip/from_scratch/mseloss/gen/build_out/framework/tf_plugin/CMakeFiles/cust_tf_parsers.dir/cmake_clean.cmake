file(REMOVE_RECURSE
  "CMakeFiles/cust_tf_parsers.dir/tensorflow_mseloss_custom_plugin.cc.o"
  "CMakeFiles/cust_tf_parsers.dir/tensorflow_mseloss_custom_plugin.cc.o.d"
  "libcust_tf_parsers.pdb"
  "libcust_tf_parsers.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/cust_tf_parsers.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
