op_host/CMakeFiles/cust_optiling.dir/mseloss_custom.cpp.o: \
 /root/catman/prepared/from_scratch/mseloss/gen/op_host/mseloss_custom.cpp \
 /usr/include/stdc-predef.h \
 /root/catman/prepared/from_scratch/mseloss/gen/op_host/mseloss_custom_tiling.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/register/tilingdata_base.h \
 /usr/include/c++/11/vector /usr/include/c++/11/bits/stl_algobase.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/c++config.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/aarch64-linux-gnu/bits/wordsize.h \
 /usr/include/aarch64-linux-gnu/bits/timesize.h \
 /usr/include/aarch64-linux-gnu/sys/cdefs.h \
 /usr/include/aarch64-linux-gnu/bits/long-double.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs.h \
 /usr/include/aarch64-linux-gnu/gnu/stubs-lp64.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/cpu_defines.h \
 /usr/include/c++/11/bits/functexcept.h \
 /usr/include/c++/11/bits/exception_defines.h \
 /usr/include/c++/11/bits/cpp_type_traits.h \
 /usr/include/c++/11/ext/type_traits.h \
 /usr/include/c++/11/ext/numeric_traits.h \
 /usr/include/c++/11/bits/stl_pair.h /usr/include/c++/11/bits/move.h \
 /usr/include/c++/11/type_traits \
 /usr/include/c++/11/bits/stl_iterator_base_types.h \
 /usr/include/c++/11/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/11/bits/concept_check.h \
 /usr/include/c++/11/debug/assertions.h \
 /usr/include/c++/11/bits/stl_iterator.h \
 /usr/include/c++/11/bits/ptr_traits.h /usr/include/c++/11/debug/debug.h \
 /usr/include/c++/11/bits/predefined_ops.h \
 /usr/include/c++/11/bits/allocator.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/c++allocator.h \
 /usr/include/c++/11/ext/new_allocator.h /usr/include/c++/11/new \
 /usr/include/c++/11/bits/exception.h \
 /usr/include/c++/11/bits/memoryfwd.h \
 /usr/include/c++/11/bits/stl_construct.h \
 /usr/include/c++/11/bits/stl_uninitialized.h \
 /usr/include/c++/11/ext/alloc_traits.h \
 /usr/include/c++/11/bits/alloc_traits.h \
 /usr/include/c++/11/bits/stl_vector.h \
 /usr/include/c++/11/initializer_list \
 /usr/include/c++/11/bits/stl_bvector.h \
 /usr/include/c++/11/bits/functional_hash.h \
 /usr/include/c++/11/bits/hash_bytes.h \
 /usr/include/c++/11/bits/range_access.h \
 /usr/include/c++/11/bits/vector.tcc /usr/include/c++/11/map \
 /usr/include/c++/11/bits/stl_tree.h \
 /usr/include/c++/11/bits/stl_function.h \
 /usr/include/c++/11/backward/binders.h \
 /usr/include/c++/11/ext/aligned_buffer.h \
 /usr/include/c++/11/bits/stl_map.h /usr/include/c++/11/tuple \
 /usr/include/c++/11/utility /usr/include/c++/11/bits/stl_relops.h \
 /usr/include/c++/11/array /usr/include/c++/11/bits/uses_allocator.h \
 /usr/include/c++/11/bits/invoke.h \
 /usr/include/c++/11/bits/stl_multimap.h \
 /usr/include/c++/11/bits/erase_if.h /usr/include/c++/11/memory \
 /usr/include/c++/11/bits/stl_tempbuf.h \
 /usr/include/c++/11/bits/stl_raw_storage_iter.h \
 /usr/include/c++/11/bits/align.h /usr/include/c++/11/bit \
 /usr/lib/gcc/aarch64-linux-gnu/11/include/stdint.h /usr/include/stdint.h \
 /usr/include/aarch64-linux-gnu/bits/libc-header-start.h \
 /usr/include/aarch64-linux-gnu/bits/types.h \
 /usr/include/aarch64-linux-gnu/bits/typesizes.h \
 /usr/include/aarch64-linux-gnu/bits/time64.h \
 /usr/include/aarch64-linux-gnu/bits/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-intn.h \
 /usr/include/aarch64-linux-gnu/bits/stdint-uintn.h \
 /usr/include/c++/11/bits/unique_ptr.h \
 /usr/include/c++/11/bits/shared_ptr.h /usr/include/c++/11/iosfwd \
 /usr/include/c++/11/bits/stringfwd.h /usr/include/c++/11/bits/postypes.h \
 /usr/include/c++/11/cwchar /usr/include/wchar.h \
 /usr/include/aarch64-linux-gnu/bits/floatn.h \
 /usr/include/aarch64-linux-gnu/bits/floatn-common.h \
 /usr/lib/gcc/aarch64-linux-gnu/11/include/stddef.h \
 /usr/lib/gcc/aarch64-linux-gnu/11/include/stdarg.h \
 /usr/include/aarch64-linux-gnu/bits/types/wint_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/aarch64-linux-gnu/bits/wchar2.h \
 /usr/include/c++/11/bits/shared_ptr_base.h /usr/include/c++/11/typeinfo \
 /usr/include/c++/11/bits/allocated_ptr.h \
 /usr/include/c++/11/bits/refwrap.h /usr/include/c++/11/ext/atomicity.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/gthr.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/gthr-default.h \
 /usr/include/pthread.h /usr/include/sched.h \
 /usr/include/aarch64-linux-gnu/bits/types/time_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/aarch64-linux-gnu/bits/endian.h \
 /usr/include/aarch64-linux-gnu/bits/endianness.h \
 /usr/include/aarch64-linux-gnu/bits/sched.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_sched_param.h \
 /usr/include/aarch64-linux-gnu/bits/cpu-set.h /usr/include/time.h \
 /usr/include/aarch64-linux-gnu/bits/time.h \
 /usr/include/aarch64-linux-gnu/bits/timex.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/aarch64-linux-gnu/bits/types/clock_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_tm.h \
 /usr/include/aarch64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/timer_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_itimerspec.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/aarch64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/aarch64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/aarch64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/aarch64-linux-gnu/bits/struct_mutex.h \
 /usr/include/aarch64-linux-gnu/bits/struct_rwlock.h \
 /usr/include/aarch64-linux-gnu/bits/setjmp.h \
 /usr/include/aarch64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct___jmp_buf_tag.h \
 /usr/include/aarch64-linux-gnu/bits/pthread_stack_min-dynamic.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/atomic_word.h \
 /usr/include/aarch64-linux-gnu/sys/single_threaded.h \
 /usr/include/c++/11/ext/concurrence.h /usr/include/c++/11/exception \
 /usr/include/c++/11/bits/exception_ptr.h \
 /usr/include/c++/11/bits/cxxabi_init_exception.h \
 /usr/include/c++/11/bits/nested_exception.h \
 /usr/include/c++/11/bits/shared_ptr_atomic.h \
 /usr/include/c++/11/bits/atomic_base.h \
 /usr/include/c++/11/bits/atomic_lockfree_defines.h \
 /usr/include/c++/11/backward/auto_ptr.h /usr/include/c++/11/cstring \
 /usr/include/string.h /usr/include/strings.h \
 /usr/include/aarch64-linux-gnu/bits/strings_fortified.h \
 /usr/include/aarch64-linux-gnu/bits/string_fortified.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/securec.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/securectype.h \
 /usr/include/stdio.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/aarch64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/aarch64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/aarch64-linux-gnu/bits/stdio_lim.h \
 /usr/include/aarch64-linux-gnu/bits/stdio.h \
 /usr/include/aarch64-linux-gnu/bits/stdio2.h \
 /usr/include/c++/11/stdlib.h /usr/include/c++/11/cstdlib \
 /usr/include/stdlib.h /usr/include/aarch64-linux-gnu/bits/waitflags.h \
 /usr/include/aarch64-linux-gnu/bits/waitstatus.h \
 /usr/include/aarch64-linux-gnu/sys/types.h /usr/include/endian.h \
 /usr/include/aarch64-linux-gnu/bits/byteswap.h \
 /usr/include/aarch64-linux-gnu/bits/uintn-identity.h \
 /usr/include/aarch64-linux-gnu/sys/select.h \
 /usr/include/aarch64-linux-gnu/bits/select.h \
 /usr/include/aarch64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/aarch64-linux-gnu/bits/select2.h /usr/include/alloca.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-bsearch.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib-float.h \
 /usr/include/aarch64-linux-gnu/bits/stdlib.h \
 /usr/include/c++/11/bits/std_abs.h /usr/include/errno.h \
 /usr/include/aarch64-linux-gnu/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/aarch64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/aarch64-linux-gnu/bits/types/error_t.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/ascend_string.h \
 /usr/include/c++/11/string /usr/include/c++/11/bits/char_traits.h \
 /usr/include/c++/11/cstdint /usr/include/c++/11/bits/localefwd.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/c++locale.h \
 /usr/include/c++/11/clocale /usr/include/locale.h \
 /usr/include/aarch64-linux-gnu/bits/locale.h /usr/include/c++/11/cctype \
 /usr/include/ctype.h /usr/include/c++/11/bits/ostream_insert.h \
 /usr/include/c++/11/bits/cxxabi_forced.h \
 /usr/include/c++/11/bits/basic_string.h \
 /usr/include/c++/11/ext/string_conversions.h /usr/include/c++/11/cstdio \
 /usr/include/c++/11/cerrno /usr/include/c++/11/bits/charconv.h \
 /usr/include/c++/11/bits/basic_string.tcc /usr/include/c++/11/functional \
 /usr/include/c++/11/bits/std_function.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/types.h \
 /usr/include/c++/11/atomic \
 /usr/local/Ascend/ascend-toolkit/latest/include/register/op_def_registry.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/register/op_def.h \
 /usr/include/c++/11/iostream /usr/include/c++/11/ostream \
 /usr/include/c++/11/ios /usr/include/c++/11/bits/ios_base.h \
 /usr/include/c++/11/bits/locale_classes.h \
 /usr/include/c++/11/bits/locale_classes.tcc \
 /usr/include/c++/11/system_error \
 /usr/include/aarch64-linux-gnu/c++/11/bits/error_constants.h \
 /usr/include/c++/11/stdexcept /usr/include/c++/11/streambuf \
 /usr/include/c++/11/bits/streambuf.tcc \
 /usr/include/c++/11/bits/basic_ios.h \
 /usr/include/c++/11/bits/locale_facets.h /usr/include/c++/11/cwctype \
 /usr/include/wctype.h /usr/include/aarch64-linux-gnu/bits/wctype-wchar.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/ctype_base.h \
 /usr/include/c++/11/bits/streambuf_iterator.h \
 /usr/include/aarch64-linux-gnu/c++/11/bits/ctype_inline.h \
 /usr/include/c++/11/bits/locale_facets.tcc \
 /usr/include/c++/11/bits/basic_ios.tcc \
 /usr/include/c++/11/bits/ostream.tcc /usr/include/c++/11/istream \
 /usr/include/c++/11/bits/istream.tcc \
 /usr/local/Ascend/ascend-toolkit/latest/include/register/op_impl_registry.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/ge_error_codes.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/compiler_def.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/register/op_impl_kernel_registry.h \
 /usr/include/c++/11/unordered_set /usr/include/c++/11/bits/hashtable.h \
 /usr/include/c++/11/bits/hashtable_policy.h \
 /usr/include/c++/11/bits/enable_special_members.h \
 /usr/include/c++/11/bits/unordered_set.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/base_type.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/infer_shape_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/shape.h \
 /usr/include/c++/11/limits \
 /usr/local/Ascend/ascend-toolkit/latest/include/utils/extern_math_util.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/tensor.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/storage_shape.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/storage_format.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/expand_dims_type.h \
 /usr/include/c++/11/cstddef \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/tensor_data.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/runtime_attrs.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/continuous_vector.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/external/ge_common/ge_api_error_codes.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/external/ge_common/ge_error_codes.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/external/ge_common/ge_api_types.h \
 /usr/include/c++/11/set /usr/include/c++/11/bits/stl_set.h \
 /usr/include/c++/11/bits/stl_multiset.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/tensor.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./ge_error_codes.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./types.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/ascend_string.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/extended_kernel_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/kernel_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/kernel_run_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/context_extend.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/compute_node_info.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/inference_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/tensor.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/types.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/resource_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/ge_error_codes.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/infer_shape_range_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/range.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/tiling_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/tiling_data.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/continuous_vector.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/runtime_attrs.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/op_execute_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/shape.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/tensor.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/extended_kernel_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/ge/ge_allocator.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/exe_graph/runtime/infer_datatype_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/operator_reg.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/operator.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./inference_context.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./tensor.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/operator_factory.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./operator.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./ascend_string.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/graph.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/./gnode.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/././ge_error_codes.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/././types.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/././tensor.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/graph/././ascend_string.h \
 /usr/local/Ascend/ascend-toolkit/latest/include/register/op_def_factory.h
